# Mario Milestone 9 — MM Gameplay Bridge

This milestone integrates Mario with Majora's Mask gameplay by **observing and
preserving the existing Player systems** instead of duplicating them.

## Added

- `patches/mario_gameplay.h/.c`
- health/defeated state mirrored into `MarioState`
- gameplay interaction state
- water state bridge
- cutscene/interaction awareness
- gameplay invulnerability timer field
- scene-safe initialization

## MM systems kept authoritative

The bridge does not replace MM's existing implementation of:

- damage and collision responses
- hearts/health UI
- NPC interactions
- doors
- switches
- item pickup
- cutscenes
- scripted Player control
- room/scene transitions

That is intentional. Mario is still backed by the MM `Player` actor, so
existing game logic continues to see a Player where it expects one.

## Next integration

A real Mario asset/gameplay adapter can now consume:

- `gMarioState.health`
- `gMarioState.maxHealth`
- `gMarioState.defeated`
- `gMarioState.inWater`
- `Mario_GameplayCanInteract()`

The actual visual model and action layer remain independent from MM's gameplay
scripts.

## Important

This is a source milestone and has not been compiled here because the
uploaded Zelda64Recomp archive does not include all git submodule contents.
