# Mario asset package

This directory is intentionally empty of copyrighted Nintendo game assets.

## What the mod expects

Provide a Mario package through the asset boundary in `patches/mario_asset.h`:

- a compatible MM/Recomp skeleton
- a display-list/material package
- an animation table containing the actions listed in `mario_animation.h`

Recommended animation slots:

| Slot | Animation |
|---|---|
| 0 | idle |
| 1 | walk |
| 2 | run |
| 3 | jump |
| 4 | fall |
| 5 | double_jump |
| 6 | triple_jump |
| 7 | long_jump |
| 8 | side_flip |
| 9 | backflip |
| 10 | dive |
| 11 | ground_pound |
| 12 | wall_kick |
| 13 | slide |
| 14 | swim |
| 15 | water_idle |
| 16 | land |

The gameplay code does not depend on the source format of the asset. The
importer/conversion step should produce the runtime structures expected by
`MarioAssetPackage`.

Do not place ripped Nintendo ROM assets into a public distribution archive.
Use assets you created yourself or have permission to redistribute.
