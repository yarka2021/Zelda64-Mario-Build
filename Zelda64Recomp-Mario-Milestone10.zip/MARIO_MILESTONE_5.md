# Mario Controller — Milestone 5

This milestone polishes the SM64-style controller without replacing Majora's Mask collision.

## Added

- Jump input buffering (5 frames).
- Coyote time (5 frames) for forgiving jump timing at ledges.
- Wall-kick cooldown to prevent repeated same-wall kicks.
- Gradual air turning instead of snapping the yaw to the stick.
- Better dive steering and momentum preservation.
- Water detection through MM's `WaterBox_GetSurface1` API.
- Reduced gravity / terminal speed while swimming or falling in water.
- Water jump.
- Slope slide remains based on the MM floor polygon normal.
- Existing wall/ceiling/floor collision adapter remains unchanged.

## Important

The archive is source-only. It is not claimed to be a verified compiled build because the uploaded base project does not contain populated git submodules. Zelda64Recomp's official build instructions require recursive submodules and the correct decompressed NTSC-U Majora's Mask ROM.
