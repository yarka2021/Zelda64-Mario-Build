# Mario Milestone 7 — Player Draw Adapter

This milestone connects the Mario animation state to the existing MM Player rendering path.

## What changed

- `Mario_ModelDraw()` is now a real draw adapter around `Player_DrawImpl`.
- `Mario_AnimationCurrent()` exposes the selected animation to the renderer.
- `MarioAssetPackage` has a `bind()` callback. A user-supplied asset adapter can:
  1. select the Mario skeleton,
  2. select the animation for the current `MarioAnimation`,
  3. initialize/update `player->skelAnime`,
  4. return `true`.
- `Player_DrawGameplay()` checks `Mario_ModelIsReady()`. If a valid Mario package is installed, it draws Mario and skips vanilla Link drawing. If not, vanilla Link rendering remains untouched.
- No Nintendo Mario model, textures, animations, or extracted copyrighted assets are included.

## Asset adapter contract

A legal/custom asset implementation should provide `MarioAssetBindFn` and install a package with:

- `skeleton`
- `animationTable`
- `animationCount`
- `displayList`
- `bind`

The binder owns the concrete `SkelAnime` setup because skeleton formats and animation storage can differ between custom asset pipelines.

## Important

The source archive does not contain a Mario model. Milestone 7 is therefore a functional renderer boundary, not a bundled Mario character asset.
