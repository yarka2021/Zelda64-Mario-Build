# Mario Milestone 4 — MM Collision Adapter

This milestone adds a collision layer between Mario-style physics and Majora's Mask.

## Added

- `mario_collision.c/.h`
- MM `BgCheck_EntitySphVsWall3` wall resolution
- wall normal capture
- wall-kick using the actual MM wall normal
- ceiling collision via `BgCheck_EntityCheckCeiling`
- floor normal extraction via `CollisionPoly_GetNormalF`
- steep-slope detection and Mario slide state
- projected downhill slide acceleration
- velocity removal when moving into a wall

## Architecture

Mario physics still owns the desired movement, but Majora's Mask owns collision geometry:

`Mario input -> Mario action/physics -> MM BgCheck -> resolved Player position`

No SM64 collision implementation is copied into the project.

## Important

This archive is a source milestone, not a verified compiled ROM/ELF. The uploaded project does not contain the `lib/mm-decomp` and other git submodules, so the complete project must be initialized locally before building.

## Next

Milestone 5 should add:

- more accurate SM64 slope acceleration
- wall-kick cooldown / wall-stick timing
- slide braking and slide jump
- water/swimming interaction
- moving-platform handling
- Mario hitbox tuning
