#include "mario_collision.h"
#include "mario_state.h"
#include "z64.h"
#include "functions.h"
#include <math.h>

/*
 * Milestone 4 collision adapter.
 *
 * We use MM's own BgCheck routines instead of copying SM64 collision code.
 * The Mario controller supplies the desired movement; MM resolves the actual
 * world collision.
 */

#define MARIO_COLLISION_EPSILON 1.0f

bool Mario_CollisionMove(PlayState* play, Player* player, f32 radius, f32 checkHeight) {
    Vec3f prev;
    Vec3f next;
    Vec3f result;
    CollisionPoly* wallPoly = NULL;
    s32 bgId = BGCHECK_SCENE;
    bool hit;

    prev = player->actor.world.pos;
    next = prev;
    next.x += player->actor.velocity.x;
    next.z += player->actor.velocity.z;
    result = next;

    hit = BgCheck_EntitySphVsWall3(
        &play->colCtx,
        &result,
        &next,
        &prev,
        radius,
        &wallPoly,
        &bgId,
        &player->actor,
        checkHeight
    );

    gMarioState.wallContact = hit ? 1 : 0;

    if (hit) {
        f32 nx = 0.0f;
        f32 ny = 0.0f;
        f32 nz = 0.0f;

        player->actor.world.pos.x = result.x;
        player->actor.world.pos.z = result.z;

        if (wallPoly != NULL) {
            CollisionPoly_GetNormalF(wallPoly, &nx, &ny, &nz);
            gMarioState.wallNormal.x = nx;
            gMarioState.wallNormal.y = ny;
            gMarioState.wallNormal.z = nz;
        }

        /* Remove velocity directed into the wall, preserving tangential motion. */
        {
            f32 dot = player->actor.velocity.x * gMarioState.wallNormal.x +
                      player->actor.velocity.z * gMarioState.wallNormal.z;

            if (dot < 0.0f) {
                player->actor.velocity.x -= gMarioState.wallNormal.x * dot;
                player->actor.velocity.z -= gMarioState.wallNormal.z * dot;
            }
        }
    } else {
        player->actor.world.pos.x = next.x;
        player->actor.world.pos.z = next.z;
    }

    return hit;
}

bool Mario_CollisionCheckCeiling(PlayState* play, Player* player, f32 checkHeight) {
    f32 ceilingY;
    CollisionPoly* ceilingPoly = NULL;
    s32 bgId = BGCHECK_SCENE;

    ceilingY = player->actor.world.pos.y;

    if (BgCheck_EntityCheckCeiling(
            &play->colCtx,
            &ceilingY,
            &player->actor.world.pos,
            checkHeight,
            &ceilingPoly,
            &bgId,
            &player->actor)) {
        if (player->actor.velocity.y > 0.0f) {
            player->actor.velocity.y = 0.0f;
        }

        player->actor.world.pos.y = ceilingY - MARIO_COLLISION_EPSILON;
        return true;
    }

    return false;
}

void Mario_CollisionUpdateFloorNormal(Player* player) {
    f32 nx = 0.0f;
    f32 ny = 1.0f;
    f32 nz = 0.0f;

    if (player->actor.floorPoly != NULL) {
        CollisionPoly_GetNormalF(player->actor.floorPoly, &nx, &ny, &nz);
    }

    gMarioState.floorNormal.x = nx;
    gMarioState.floorNormal.y = ny;
    gMarioState.floorNormal.z = nz;
}
