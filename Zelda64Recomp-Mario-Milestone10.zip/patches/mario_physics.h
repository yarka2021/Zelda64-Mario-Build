#ifndef __MARIO_PHYSICS_H__
#define __MARIO_PHYSICS_H__

#include "global.h"

void Mario_PhysicsUpdate(PlayState* play, Player* player);

#endif
