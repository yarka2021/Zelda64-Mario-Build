#ifndef __MARIO_GAMEPLAY_H__
#define __MARIO_GAMEPLAY_H__

#include "global.h"
#include "mario_state.h"

typedef enum {
    MARIO_GAMEPLAY_ALIVE = 0,
    MARIO_GAMEPLAY_DAMAGED,
    MARIO_GAMEPLAY_DEFEATED,
} MarioGameplayState;

typedef struct {
    MarioGameplayState state;
    s16 health;
    s16 maxHealth;
    u16 invulnerabilityTimer;
    u8 interactionActive;
    u8 inWater;
} MarioGameplay;

extern MarioGameplay gMarioGameplay;

void Mario_GameplayInit(void);
void Mario_GameplaySceneReset(void);
void Mario_GameplayPreUpdate(PlayState* play);
void Mario_GameplayPostUpdate(PlayState* play);
bool Mario_GameplayCanInteract(void);
bool Mario_GameplayIsAlive(void);

#endif
