#ifndef __MARIO_PROPORTIONS_H__
#define __MARIO_PROPORTIONS_H__

#include "global.h"

typedef struct {
    f32 modelScale;
    f32 cameraTargetHeight;
    f32 cameraEyeHeight;
    f32 cameraEyeFollow;
    f32 wallRadius;
    f32 wallHeight;
} MarioProportions;

const MarioProportions* Mario_GetProportions(void);
void Mario_ApplyModelProportions(Player* player);
void Mario_ResetModelProportions(void);
f32 Mario_GetWallRadius(void);
f32 Mario_GetWallHeight(void);

#endif
