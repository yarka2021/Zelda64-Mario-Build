#ifndef __MARIO_STATE_H__
#define __MARIO_STATE_H__

#include "global.h"


typedef enum {
    MARIO_DAMAGE_NONE = 0,
    MARIO_DAMAGE_GENERIC,
    MARIO_DAMAGE_FIRE,
    MARIO_DAMAGE_LAVA,
    MARIO_DAMAGE_ICE,
    MARIO_DAMAGE_ELECTRIC,
    MARIO_DAMAGE_FALL,
} MarioDamageType;

typedef enum {
    MARIO_LIFE_ALIVE = 0,
    MARIO_LIFE_HURT,
    MARIO_LIFE_DEAD,
    MARIO_LIFE_RESPAWNING,
} MarioLifeState;

typedef struct {
    f32 x;
    f32 y;
    f32 z;
} MarioVec3f;

typedef enum {
    MARIO_ACTION_IDLE = 0,
    MARIO_ACTION_WALK,
    MARIO_ACTION_RUN,
    MARIO_ACTION_JUMP,
    MARIO_ACTION_DOUBLE_JUMP,
    MARIO_ACTION_TRIPLE_JUMP,
    MARIO_ACTION_FREEFALL,
    MARIO_ACTION_LONG_JUMP,
    MARIO_ACTION_SIDE_FLIP,
    MARIO_ACTION_BACKFLIP,
    MARIO_ACTION_DIVE,
    MARIO_ACTION_GROUND_POUND,
    MARIO_ACTION_WALL_KICK,
    MARIO_ACTION_SLIDE,
    MARIO_ACTION_ATTACK,
    MARIO_ACTION_KICK,
    MARIO_ACTION_STOMP,
    MARIO_ACTION_HURT,
    MARIO_ACTION_LAVA_DAMAGE,
    MARIO_ACTION_ELECTRIC_DAMAGE,
    MARIO_ACTION_DEATH,
    MARIO_ACTION_FALL,
} MarioAction;

typedef struct {
    MarioVec3f pos;
    MarioVec3f velocity;

    s16 yaw;
    s16 pitch;
    s16 roll;

    f32 forwardVelocity;
    f32 intendedMagnitude;

    f32 stickX;
    f32 stickY;

    u16 heldButtons;
    u16 pressedButtons;

    MarioAction action;
    u16 actionTimer;
    u16 actionState;

    u8 jumpCount;
    u8 grounded;
    u8 wallContact;
    u8 inWater;
    u8 jumpBufferTimer;
    u8 coyoteTimer;
    u8 wallKickCooldown;
    u8 gameplayInvulnTimer;
    u8 defeated;
    s16 health;
    s16 maxHealth;

    MarioVec3f wallNormal;
    MarioVec3f floorNormal;

    u32 frame;

    s16 health;
    s16 maxHealth;
    MarioDamageType damageType;
    MarioLifeState lifeState;
    u16 damageTimer;
    u16 invincibilityTimer;
    u8 attackActive;
    u8 attackTimer;
    u8 stompActive;
    u8 reserved;
} MarioState;

extern MarioState gMarioState;

void Mario_InitState(void);

#endif
