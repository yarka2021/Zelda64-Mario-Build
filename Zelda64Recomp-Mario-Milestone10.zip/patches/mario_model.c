#include "mario_model.h"
#include "mario_animation.h"
#include "mario_proportions.h"
#include "z64.h"

static bool sMarioModelReady = false;

void Mario_ModelInit(void) {
    Mario_AssetInit();
    sMarioModelReady = false;
}

bool Mario_ModelInstall(const MarioAssetPackage* package) {
    sMarioModelReady = Mario_AssetInstall(package);
    return sMarioModelReady;
}

bool Mario_ModelIsReady(void) {
    return sMarioModelReady && Mario_AssetGet()->valid;
}

bool Mario_ModelBind(PlayState* play, Player* player, MarioAnimation animation) {
    if (!Mario_ModelIsReady() || play == NULL || player == NULL) {
        return false;
    }

    /*
     * The asset package owns the actual skeleton/animation conversion.
     * A legal user-supplied asset adapter can initialize player->skelAnime
     * with its own skeleton and animation here, then Player_DrawImpl below
     * renders that skeleton.
     */
    (void)animation;
    return Mario_AssetBind(play, player, animation);
}

void Mario_ModelDraw(PlayState* play, Player* player, s32 lod, Gfx* cullDList,
                     OverrideLimbDrawFlex overrideLimbDraw) {
    const MarioAssetPackage* asset;
    MarioAnimation animation;

    if (!Mario_ModelIsReady() || play == NULL || player == NULL) {
        return;
    }

    asset = Mario_AssetGet();
    animation = Mario_AnimationCurrent();

    if (!Mario_ModelBind(play, player, animation)) {
        return;
    }

    /* Scale the Player actor to the configured Mario proportions only when
     * a custom Mario asset is actually installed. */
    Mario_ApplyModelProportions(player);

    OPEN_DISPS(play->state.gfxCtx);

    gSPSegment(POLY_OPA_DISP++, 0x0C, cullDList);
    gSPSegment(POLY_XLU_DISP++, 0x0C, cullDList);

    Player_DrawImpl(play, player->skelAnime.skeleton, player->skelAnime.jointTable,
                     player->skelAnime.dListCount, lod, player->transformation,
                     0, player->actor.shape.face, overrideLimbDraw,
                     Player_PostLimbDrawGameplay, &player->actor);

    CLOSE_DISPS(play->state.gfxCtx);

    (void)asset;
}
