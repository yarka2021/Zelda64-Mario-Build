#include "mario_proportions.h"
#include "z64.h"

static const MarioProportions sMarioProportions = {
    /*
     * These are deliberately isolated tuning values. They do not contain
     * Nintendo model data; they describe the scale relationship between the
     * Player actor, the user-supplied Mario asset, and the camera.
     */
    .modelScale = 0.90f,
    .cameraTargetHeight = 92.0f,
    .cameraEyeHeight = 105.0f,
    .cameraEyeFollow = 0.55f,
    .wallRadius = 18.0f,
    .wallHeight = 55.0f,
};

static Vec3f sBasePlayerScale;
static bool sBaseScaleValid = false;

const MarioProportions* Mario_GetProportions(void) {
    return &sMarioProportions;
}

void Mario_ResetModelProportions(void) {
    sBaseScaleValid = false;
}

void Mario_ApplyModelProportions(Player* player) {
    if (player == NULL) {
        return;
    }

    if (!sBaseScaleValid) {
        sBasePlayerScale = player->actor.scale;
        sBaseScaleValid = true;
    }

    player->actor.scale.x = sBasePlayerScale.x * sMarioProportions.modelScale;
    player->actor.scale.y = sBasePlayerScale.y * sMarioProportions.modelScale;
    player->actor.scale.z = sBasePlayerScale.z * sMarioProportions.modelScale;
}

f32 Mario_GetWallRadius(void) {
    return sMarioProportions.wallRadius;
}

f32 Mario_GetWallHeight(void) {
    return sMarioProportions.wallHeight;
}
