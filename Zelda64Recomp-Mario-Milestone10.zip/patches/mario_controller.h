#ifndef __MARIO_CONTROLLER_H__
#define __MARIO_CONTROLLER_H__

#include "global.h"

void Mario_ControllerInit(void);
void Mario_PrePlayUpdate(PlayState* play);
void Mario_PlayerHook(PlayState* play);

#endif
