#ifndef __MARIO_MODEL_H__
#define __MARIO_MODEL_H__

#include "global.h"
#include "mario_asset.h"

void Mario_ModelInit(void);
bool Mario_ModelIsReady(void);
bool Mario_ModelInstall(const MarioAssetPackage* package);
bool Mario_ModelBind(PlayState* play, Player* player, MarioAnimation animation);

void Mario_ModelDraw(PlayState* play, Player* player, s32 lod, Gfx* cullDList,
                     OverrideLimbDrawFlex overrideLimbDraw);

#endif
