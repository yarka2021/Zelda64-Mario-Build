#ifndef __MARIO_COLLISION_H__
#define __MARIO_COLLISION_H__

#include "global.h"

typedef struct {
    bool hitWall;
    bool hitCeiling;
    CollisionPoly* wallPoly;
    CollisionPoly* ceilingPoly;
    s32 wallBgId;
    s32 ceilingBgId;
    Vec3f wallNormal;
    f32 floorNormalY;
} MarioCollision;

bool Mario_CollisionMove(PlayState* play, Player* player, f32 radius, f32 checkHeight);
bool Mario_CollisionCheckCeiling(PlayState* play, Player* player, f32 checkHeight);
void Mario_CollisionUpdateFloorNormal(Player* player);

#endif
