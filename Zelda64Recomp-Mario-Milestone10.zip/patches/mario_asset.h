#ifndef __MARIO_ASSET_H__
#define __MARIO_ASSET_H__

#include "global.h"
#include "mario_animation.h"

/*
 * Runtime-neutral Mario asset package.
 *
 * The package contains pointers to a skeleton, animation table and display
 * lists supplied by the mod author. This header deliberately does not contain
 * Nintendo assets.
 */
typedef bool (*MarioAssetBindFn)(PlayState* play, Player* player, const MarioAssetPackage* package,
                                  MarioAnimation animation);

typedef struct {
    const char* name;
    const void* skeleton;
    const void* animationTable;
    u16 animationCount;
    const Gfx* displayList;
    bool valid;
    MarioAssetBindFn bind;
} MarioAssetPackage;

void Mario_AssetInit(void);
bool Mario_AssetInstall(const MarioAssetPackage* package);
const MarioAssetPackage* Mario_AssetGet(void);
const void* Mario_AssetAnimation(MarioAnimation animation);\nbool Mario_AssetBind(PlayState* play, Player* player, MarioAnimation animation);

#endif
