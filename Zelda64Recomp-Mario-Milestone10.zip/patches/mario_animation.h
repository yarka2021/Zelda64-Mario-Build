#ifndef __MARIO_ANIMATION_H__
#define __MARIO_ANIMATION_H__

#include "global.h"
#include "mario_state.h"

typedef enum {
    MARIO_ANIM_IDLE = 0,
    MARIO_ANIM_WALK,
    MARIO_ANIM_RUN,
    MARIO_ANIM_JUMP,
    MARIO_ANIM_FALL,
    MARIO_ANIM_DOUBLE_JUMP,
    MARIO_ANIM_TRIPLE_JUMP,
    MARIO_ANIM_LONG_JUMP,
    MARIO_ANIM_SIDE_FLIP,
    MARIO_ANIM_BACKFLIP,
    MARIO_ANIM_DIVE,
    MARIO_ANIM_GROUND_POUND,
    MARIO_ANIM_WALL_KICK,
    MARIO_ANIM_SLIDE,
    MARIO_ANIM_SWIM,
    MARIO_ANIM_WATER_IDLE,
    MARIO_ANIM_LAND,
} MarioAnimation;

void Mario_AnimationInit(void);
MarioAnimation Mario_AnimationForAction(MarioAction action, bool inWater);
void Mario_AnimationUpdate(PlayState* play, Player* player);\nMarioAnimation Mario_AnimationCurrent(void);
const char* Mario_AnimationName(MarioAnimation animation);

#endif
