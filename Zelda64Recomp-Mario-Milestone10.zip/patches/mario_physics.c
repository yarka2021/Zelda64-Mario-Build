#include "mario_physics.h"
#include "mario_state.h"
#include "mario_collision.h"
#include "mario_proportions.h"
#include "z64.h"
#include "functions.h"
#include <math.h>

/*
 * Milestone 5: movement polish on top of Majora's Mask collision.
 *
 * This remains a controller layer. MM owns the Player actor and world
 * collision; this file owns Mario's action state and desired motion.
 */
#define MARIO_WALK_SPEED          4.5f
#define MARIO_RUN_SPEED           7.5f
#define MARIO_ACCEL               0.85f
#define MARIO_DECEL               0.75f
#define MARIO_AIR_ACCEL           0.42f
#define MARIO_AIR_TURN            0.16f
#define MARIO_GRAVITY            -2.4f
#define MARIO_TERMINAL_SPEED     -35.0f
#define MARIO_JUMP_SPEED          13.0f
#define MARIO_DOUBLE_JUMP         14.0f
#define MARIO_TRIPLE_JUMP         16.5f
#define MARIO_FLIP_SPEED          14.0f
#define MARIO_LONG_JUMP_SPEED     12.0f
#define MARIO_DIVE_SPEED          11.0f
#define MARIO_GROUND_POUND_Y     -12.0f
#define MARIO_FLOOR_EPSILON        2.0f
#define MARIO_STICK_DEADZONE       0.15f
#define MARIO_JUMP_CHAIN_FRAMES    18
#define MARIO_JUMP_BUFFER_FRAMES    5
#define MARIO_COYOTE_FRAMES         5
#define MARIO_DIVE_DECEL            0.32f
#define MARIO_DIVE_GRAVITY          1.75f
#define MARIO_FLIP_TURN_RATE        0x1800
#define MARIO_WALL_RADIUS          18.0f
#define MARIO_WALL_HEIGHT          55.0f
#define MARIO_WALL_KICK_SPEED      11.0f
#define MARIO_WALL_KICK_UP         13.5f
#define MARIO_WALL_KICK_COOLDOWN     6
#define MARIO_MAX_SLOPE_Y           0.55f
#define MARIO_SLIDE_ACCEL           0.65f
#define MARIO_SLIDE_FRICTION        0.08f
#define MARIO_WATER_GRAVITY         0.45f
#define MARIO_WATER_TERMINAL       -5.0f
#define MARIO_WATER_JUMP            8.0f

static f32 Mario_Approach(f32 current, f32 target, f32 amount) {
    if (current < target) {
        current += amount;
        if (current > target) current = target;
    } else if (current > target) {
        current -= amount;
        if (current < target) current = target;
    }
    return current;
}

static f32 Mario_HorizontalSpeed(Player* player) {
    return sqrtf((player->actor.velocity.x * player->actor.velocity.x) +
                 (player->actor.velocity.z * player->actor.velocity.z));
}

static void Mario_SetHorizontalFromYaw(Player* player, f32 speed) {
    player->actor.velocity.x = Math_SinS(gMarioState.yaw) * speed;
    player->actor.velocity.z = Math_CosS(gMarioState.yaw) * speed;
}

static void Mario_ReadWater(PlayState* play, Player* player) {
    WaterBox* waterBox = NULL;
    f32 surfaceY = player->actor.world.pos.y + 200.0f;

    gMarioState.inWater = WaterBox_GetSurface1(
        play, &play->colCtx,
        player->actor.world.pos.x,
        player->actor.world.pos.z,
        &surfaceY,
        &waterBox
    ) && (player->actor.world.pos.y < surfaceY + 45.0f);
}

static void Mario_UpdateHorizontal(Player* player) {
    f32 stickX = gMarioState.stickX;
    f32 stickY = -gMarioState.stickY;
    f32 magnitude = sqrtf((stickX * stickX) + (stickY * stickY));
    f32 targetSpeed;
    s16 targetYaw;
    f32 desiredX;
    f32 desiredZ;
    f32 accel;

    if (magnitude > 1.0f) magnitude = 1.0f;
    if (magnitude < MARIO_STICK_DEADZONE) magnitude = 0.0f;

    if (magnitude > 0.0f) {
        targetYaw = player->actor.shape.rot.y + (s16)Math_Atan2S(stickX, stickY);
        if (gMarioState.grounded || gMarioState.action == MARIO_ACTION_SLIDE) {
            gMarioState.yaw = targetYaw;
        } else {
            /* Air control turns Mario gradually instead of snapping. */
            gMarioState.yaw += (s16)((s16)(targetYaw - gMarioState.yaw) * MARIO_AIR_TURN);
        }

        targetSpeed = ((gMarioState.heldButtons & BTN_B) != 0) ? MARIO_RUN_SPEED : MARIO_WALK_SPEED;
        targetSpeed *= magnitude;

        desiredX = Math_SinS(gMarioState.yaw) * targetSpeed;
        desiredZ = Math_CosS(gMarioState.yaw) * targetSpeed;
        accel = gMarioState.grounded ? MARIO_ACCEL : MARIO_AIR_ACCEL;

        player->actor.velocity.x = Mario_Approach(player->actor.velocity.x, desiredX, accel);
        player->actor.velocity.z = Mario_Approach(player->actor.velocity.z, desiredZ, accel);
        gMarioState.intendedMagnitude = targetSpeed;
    } else if (gMarioState.action != MARIO_ACTION_GROUND_POUND &&
               gMarioState.action != MARIO_ACTION_DIVE) {
        accel = gMarioState.grounded ? MARIO_DECEL : MARIO_AIR_ACCEL;
        player->actor.velocity.x = Mario_Approach(player->actor.velocity.x, 0.0f, accel);
        player->actor.velocity.z = Mario_Approach(player->actor.velocity.z, 0.0f, accel);
        gMarioState.intendedMagnitude = 0.0f;
    }

    gMarioState.forwardVelocity = Mario_HorizontalSpeed(player);
}

static void Mario_StartJump(Player* player, MarioAction action, f32 speed) {
    player->actor.velocity.y = speed;
    gMarioState.grounded = false;
    gMarioState.coyoteTimer = 0;
    gMarioState.jumpBufferTimer = 0;
    gMarioState.action = action;
    gMarioState.actionTimer = 0;
}

static bool Mario_DoBufferedJump(Player* player) {
    if (gMarioState.jumpBufferTimer == 0 || (!gMarioState.grounded && gMarioState.coyoteTimer == 0)) {
        return false;
    }

    Mario_StartJump(player, MARIO_ACTION_JUMP, MARIO_JUMP_SPEED);
    gMarioState.jumpCount = 1;
    return true;
}

static void Mario_UpdateActionStart(Player* player) {
    u16 pressed = gMarioState.pressedButtons;
    bool zHeld = (gMarioState.heldButtons & BTN_Z) != 0;
    bool bPressed = (pressed & BTN_B) != 0;
    bool moving = gMarioState.forwardVelocity > 4.0f;
    bool backwards = gMarioState.stickY > 0.35f;
    bool sideways = fabsf(gMarioState.stickX) > 0.35f;

    if (pressed & BTN_A) {
        gMarioState.jumpBufferTimer = MARIO_JUMP_BUFFER_FRAMES;
    }

    if (gMarioState.inWater) {
        if ((pressed & BTN_A) && player->actor.velocity.y < MARIO_WATER_JUMP) {
            player->actor.velocity.y = MARIO_WATER_JUMP;
            gMarioState.action = MARIO_ACTION_JUMP;
            gMarioState.actionTimer = 0;
            gMarioState.grounded = false;
            gMarioState.jumpBufferTimer = 0;
            return;
        }
        if (!gMarioState.grounded) {
            gMarioState.action = MARIO_ACTION_FREEFALL;
        }
        return;
    }

    if (gMarioState.grounded || gMarioState.coyoteTimer > 0) {
        if (Mario_DoBufferedJump(player)) {
            if (zHeld && moving) {
                gMarioState.action = MARIO_ACTION_LONG_JUMP;
                player->actor.velocity.y = MARIO_LONG_JUMP_SPEED;
                Mario_SetHorizontalFromYaw(player, MARIO_LONG_JUMP_SPEED);
                return;
            }
            if (gMarioState.jumpCount == 2 && gMarioState.actionTimer <= MARIO_JUMP_CHAIN_FRAMES) {
                gMarioState.action = MARIO_ACTION_TRIPLE_JUMP;
                player->actor.velocity.y = MARIO_TRIPLE_JUMP;
                gMarioState.jumpCount = 3;
                return;
            }
            if (backwards && gMarioState.forwardVelocity < 3.0f) {
                gMarioState.action = MARIO_ACTION_BACKFLIP;
                player->actor.velocity.y = MARIO_FLIP_SPEED;
                player->actor.velocity.x *= 0.35f;
                player->actor.velocity.z *= 0.35f;
                return;
            }
            if (sideways && gMarioState.forwardVelocity < 4.0f) {
                gMarioState.action = MARIO_ACTION_SIDE_FLIP;
                player->actor.velocity.y = MARIO_FLIP_SPEED;
                gMarioState.yaw += (gMarioState.stickX < 0.0f) ? -MARIO_FLIP_TURN_RATE : MARIO_FLIP_TURN_RATE;
                Mario_SetHorizontalFromYaw(player, 7.0f);
                return;
            }
            return;
        }

        if (bPressed && zHeld && moving) {
            Mario_StartJump(player, MARIO_ACTION_LONG_JUMP, MARIO_LONG_JUMP_SPEED);
            Mario_SetHorizontalFromYaw(player, MARIO_LONG_JUMP_SPEED);
            return;
        }

        if (gMarioState.forwardVelocity > 0.5f) {
            gMarioState.action = (gMarioState.heldButtons & BTN_B) ? MARIO_ACTION_RUN : MARIO_ACTION_WALK;
        } else if (gMarioState.action != MARIO_ACTION_SLIDE) {
            gMarioState.action = MARIO_ACTION_IDLE;
        }
    } else {
        if ((pressed & BTN_A) && gMarioState.wallContact && gMarioState.wallKickCooldown == 0) {
            gMarioState.action = MARIO_ACTION_WALL_KICK;
            gMarioState.actionTimer = 0;
            gMarioState.grounded = false;
            gMarioState.jumpCount = 0;
            gMarioState.wallKickCooldown = MARIO_WALL_KICK_COOLDOWN;
            player->actor.velocity.x = gMarioState.wallNormal.x * MARIO_WALL_KICK_SPEED;
            player->actor.velocity.z = gMarioState.wallNormal.z * MARIO_WALL_KICK_SPEED;
            player->actor.velocity.y = MARIO_WALL_KICK_UP;
            gMarioState.yaw = Math_Atan2S(gMarioState.wallNormal.x, gMarioState.wallNormal.z);
            return;
        }

        if ((pressed & BTN_A) && gMarioState.jumpCount == 1 &&
            gMarioState.actionTimer <= MARIO_JUMP_CHAIN_FRAMES) {
            Mario_StartJump(player, MARIO_ACTION_DOUBLE_JUMP, MARIO_DOUBLE_JUMP);
            gMarioState.jumpCount = 2;
            return;
        }

        if (zHeld && (pressed & BTN_A) && player->actor.velocity.y < 2.0f) {
            gMarioState.action = MARIO_ACTION_GROUND_POUND;
            player->actor.velocity.y = MARIO_GROUND_POUND_Y;
            player->actor.velocity.x = 0.0f;
            player->actor.velocity.z = 0.0f;
            gMarioState.actionTimer = 0;
            return;
        }

        if (bPressed && gMarioState.action != MARIO_ACTION_GROUND_POUND) {
            gMarioState.action = MARIO_ACTION_DIVE;
            gMarioState.actionTimer = 0;
            if (Mario_HorizontalSpeed(player) < MARIO_DIVE_SPEED) {
                Mario_SetHorizontalFromYaw(player, MARIO_DIVE_SPEED);
            }
        }
    }
}

static void Mario_UpdateSpecialAction(Player* player) {
    if (gMarioState.action == MARIO_ACTION_DIVE) {
        /* Diving keeps some horizontal momentum and permits air steering. */
        player->actor.velocity.y -= MARIO_DIVE_GRAVITY;
        player->actor.velocity.x = Mario_Approach(player->actor.velocity.x,
            Math_SinS(gMarioState.yaw) * MARIO_DIVE_SPEED, MARIO_AIR_ACCEL * 0.75f);
        player->actor.velocity.z = Mario_Approach(player->actor.velocity.z,
            Math_CosS(gMarioState.yaw) * MARIO_DIVE_SPEED, MARIO_AIR_ACCEL * 0.75f);
    } else if (gMarioState.action == MARIO_ACTION_GROUND_POUND) {
        player->actor.velocity.x = 0.0f;
        player->actor.velocity.z = 0.0f;
        player->actor.velocity.y -= 1.5f;
        if (player->actor.velocity.y < MARIO_TERMINAL_SPEED) player->actor.velocity.y = MARIO_TERMINAL_SPEED;
    }
}

static void Mario_UpdateSlope(Player* player) {
    f32 nx = gMarioState.floorNormal.x;
    f32 ny = gMarioState.floorNormal.y;
    f32 nz = gMarioState.floorNormal.z;

    if (!gMarioState.grounded || ny <= 0.01f) return;

    if (ny < MARIO_MAX_SLOPE_Y) {
        f32 slideX = nx * ny;
        f32 slideZ = nz * ny;
        player->actor.velocity.x += slideX * MARIO_SLIDE_ACCEL;
        player->actor.velocity.z += slideZ * MARIO_SLIDE_ACCEL;
        player->actor.velocity.x *= (1.0f - MARIO_SLIDE_FRICTION);
        player->actor.velocity.z *= (1.0f - MARIO_SLIDE_FRICTION);
        if (gMarioState.action != MARIO_ACTION_GROUND_POUND) gMarioState.action = MARIO_ACTION_SLIDE;
    } else if (gMarioState.action == MARIO_ACTION_SLIDE) {
        gMarioState.action = MARIO_ACTION_WALK;
    }
}

static void Mario_UpdateVertical(PlayState* play, Player* player) {
    Vec3f floorPos;
    CollisionPoly* floorPoly = NULL;
    s32 bgId = BGCHECK_SCENE;
    f32 floorY;

    if (!gMarioState.grounded) {
        if (gMarioState.inWater) {
            player->actor.velocity.y -= MARIO_WATER_GRAVITY;
            if (player->actor.velocity.y < MARIO_WATER_TERMINAL) player->actor.velocity.y = MARIO_WATER_TERMINAL;
        } else if (gMarioState.action != MARIO_ACTION_DIVE &&
                   gMarioState.action != MARIO_ACTION_GROUND_POUND) {
            player->actor.velocity.y += MARIO_GRAVITY;
            if (player->actor.velocity.y < MARIO_TERMINAL_SPEED) player->actor.velocity.y = MARIO_TERMINAL_SPEED;
        }
    } else if (player->actor.velocity.y < 0.0f) {
        player->actor.velocity.y = 0.0f;
    }

    player->actor.world.pos.y += player->actor.velocity.y;

    floorPos = player->actor.world.pos;
    floorPos.y += 80.0f;
    floorY = BgCheck_EntityRaycastFloor5_3(play, &play->colCtx, &floorPoly, &bgId, &player->actor, &floorPos);

    if ((floorY != BGCHECK_Y_MIN) &&
        (player->actor.world.pos.y <= floorY + MARIO_FLOOR_EPSILON) &&
        (player->actor.velocity.y <= 0.0f)) {
        bool wasGrounded = gMarioState.grounded;
        player->actor.world.pos.y = floorY;
        player->actor.velocity.y = 0.0f;
        player->actor.floorPoly = floorPoly;
        player->actor.floorHeight = floorY;
        player->actor.floorBgId = bgId;
        gMarioState.grounded = true;
        gMarioState.coyoteTimer = 0;
        Mario_CollisionUpdateFloorNormal(player);
        Mario_UpdateSlope(player);

        if (!wasGrounded && gMarioState.action == MARIO_ACTION_LONG_JUMP) {
            gMarioState.action = MARIO_ACTION_IDLE;
        }
        if (gMarioState.action == MARIO_ACTION_GROUND_POUND ||
            gMarioState.action == MARIO_ACTION_DIVE ||
            gMarioState.action == MARIO_ACTION_SIDE_FLIP ||
            gMarioState.action == MARIO_ACTION_BACKFLIP ||
            gMarioState.action == MARIO_ACTION_WALL_KICK) {
            gMarioState.action = MARIO_ACTION_IDLE;
            gMarioState.actionTimer = 0;
            gMarioState.jumpCount = 0;
        }
        if (gMarioState.action == MARIO_ACTION_TRIPLE_JUMP) {
            gMarioState.actionTimer = 0;
            gMarioState.jumpCount = 0;
        }
    } else {
        if (gMarioState.grounded) gMarioState.coyoteTimer = MARIO_COYOTE_FRAMES;
        gMarioState.grounded = false;
    }

    if (!gMarioState.grounded && player->actor.velocity.y > 0.0f) {
        if (Mario_CollisionCheckCeiling(play, player, Mario_GetWallHeight())) {
            gMarioState.action = MARIO_ACTION_FREEFALL;
        }
    }
}

void Mario_PhysicsUpdate(PlayState* play, Player* player) {
    if (player == NULL) return;

    if (gMarioState.wallKickCooldown > 0) gMarioState.wallKickCooldown--;
    if (gMarioState.jumpBufferTimer > 0) gMarioState.jumpBufferTimer--;
    if (gMarioState.coyoteTimer > 0 && !gMarioState.grounded) gMarioState.coyoteTimer--;

    Mario_ReadWater(play, player);
    Mario_UpdateActionStart(player);

    if (gMarioState.action != MARIO_ACTION_DIVE &&
        gMarioState.action != MARIO_ACTION_GROUND_POUND) {
        Mario_UpdateHorizontal(player);
    }

    Mario_UpdateSpecialAction(player);
    Mario_CollisionMove(play, player, Mario_GetWallRadius(), Mario_GetWallHeight());
    Mario_UpdateVertical(play, player);

    player->actor.speed = Mario_HorizontalSpeed(player);
    player->actor.shape.rot.y = gMarioState.yaw;

    if (!gMarioState.grounded &&
        gMarioState.action != MARIO_ACTION_DIVE &&
        gMarioState.action != MARIO_ACTION_GROUND_POUND &&
        gMarioState.action != MARIO_ACTION_LONG_JUMP &&
        gMarioState.action != MARIO_ACTION_SIDE_FLIP &&
        gMarioState.action != MARIO_ACTION_BACKFLIP &&
        gMarioState.action != MARIO_ACTION_DOUBLE_JUMP &&
        gMarioState.action != MARIO_ACTION_TRIPLE_JUMP &&
        gMarioState.action != MARIO_ACTION_WALL_KICK) {
        gMarioState.action = MARIO_ACTION_FREEFALL;
    }

    gMarioState.pos.x = player->actor.world.pos.x;
    gMarioState.pos.y = player->actor.world.pos.y;
    gMarioState.pos.z = player->actor.world.pos.z;
    gMarioState.velocity.x = player->actor.velocity.x;
    gMarioState.velocity.y = player->actor.velocity.y;
    gMarioState.velocity.z = player->actor.velocity.z;
}
