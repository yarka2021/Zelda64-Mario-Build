#ifndef __MARIO_CAMERA_H__
#define __MARIO_CAMERA_H__

#include "global.h"

void Mario_CameraInit(void);
void Mario_CameraApplyProportions(PlayState* play);

#endif
