#include "mario_camera.h"
#include "mario_proportions.h"
#include "mario_state.h"
#include "z64.h"
#include <math.h>

static f32 Mario_CameraApproach(f32 current, f32 target, f32 step) {
    if (current < target) {
        current += step;
        if (current > target) current = target;
    } else if (current > target) {
        current -= step;
        if (current < target) current = target;
    }
    return current;
}

void Mario_CameraInit(void) {
}

void Mario_CameraApplyProportions(PlayState* play) {
    Player* player;
    Camera* camera;
    const MarioProportions* p;
    f32 desiredAtY;
    f32 desiredEyeY;
    f32 atDelta;
    f32 eyeDelta;

    if (play == NULL || play->activeCamId < 0 || play->activeCamId >= NUM_CAMS) {
        return;
    }

    player = GET_PLAYER(play);
    camera = play->cameraPtrs[play->activeCamId];

    if (player == NULL || camera == NULL) {
        return;
    }

    /*
     * Do not move the camera during cutscenes, pause, or invalid Player states.
     * Normal MM camera logic remains responsible for yaw, collision, targeting,
     * and scene-specific camera settings.
     */
    if (play->pauseCtx.state != 0 || play->pauseCtx.debugEditor != DEBUG_EDITOR_NONE) {
        return;
    }

    p = Mario_GetProportions();

    desiredAtY = player->actor.world.pos.y + p->cameraTargetHeight;
    desiredEyeY = player->actor.world.pos.y + p->cameraEyeHeight;

    /*
     * Only correct the vertical framing. Horizontal camera behavior remains
     * entirely under MM's camera system.
     */
    atDelta = desiredAtY - camera->at.y;
    eyeDelta = desiredEyeY - camera->eye.y;

    camera->at.y += Mario_CameraApproach(0.0f, atDelta, 6.0f);
    camera->eye.y += Mario_CameraApproach(0.0f, eyeDelta * p->cameraEyeFollow, 4.0f);

    /*
     * Keep the correction bounded so a scene-specific camera cannot be pulled
     * violently toward Mario after a teleport or cutscene transition.
     */
    if (fabsf(camera->at.y - desiredAtY) > 180.0f) {
        camera->at.y = desiredAtY;
    }
}

