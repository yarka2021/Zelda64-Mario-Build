#include "patches.h"
#include "mario_controller.h"
#include "mario_state.h"
#include "mario_moveset.h"
#include "mario_damage.h"
#include "mario_model.h"
#include "mario_animation.h"
#include "z64.h"
#include "mario_physics.h"
#include "mario_gameplay.h"
#include "mario_animation.h"

static bool sMarioInitialized = false;
static Vec3f sMarioPreUpdatePos;
static bool sMarioPreUpdateValid = false;

static void Mario_ReadPlayer(Player* player) {
    gMarioState.pos.x = player->actor.world.pos.x;
    gMarioState.pos.y = player->actor.world.pos.y;
    gMarioState.pos.z = player->actor.world.pos.z;

    gMarioState.velocity.x = player->actor.velocity.x;
    gMarioState.velocity.y = player->actor.velocity.y;
    gMarioState.velocity.z = player->actor.velocity.z;

    gMarioState.yaw = player->actor.shape.rot.y;
    gMarioState.pitch = player->actor.shape.rot.x;
    gMarioState.roll = player->actor.shape.rot.z;

    gMarioState.grounded = (player->actor.floorPoly != NULL);
}

static void Mario_ReadInput(PlayState* play) {
    Input* input = &play->state.input[0];

    gMarioState.stickX = (f32)input->rel.stick_x / 127.0f;
    gMarioState.stickY = (f32)input->rel.stick_y / 127.0f;
    gMarioState.heldButtons = input->cur.button;
    gMarioState.pressedButtons = input->press.button;

    gMarioState.stickX = CLAMP(gMarioState.stickX, -1.0f, 1.0f);
    gMarioState.stickY = CLAMP(gMarioState.stickY, -1.0f, 1.0f);
}

void Mario_ControllerInit(void) {
    Mario_InitState();
    Mario_MovesetInit();
    Mario_DamageInit();
    Mario_AnimationInit();
    Mario_ModelInit();
    Mario_GameplayInit();
    sMarioInitialized = true;
}

void Mario_PrePlayUpdate(PlayState* play) {
    Player* player = GET_PLAYER(play);

    if (player == NULL) {
        sMarioPreUpdateValid = false;
        return;
    }

    sMarioPreUpdatePos = player->actor.world.pos;
    sMarioPreUpdateValid = true;
}

void Mario_PlayerHook(PlayState* play) {
    Player* player;

    if (!sMarioInitialized) Mario_ControllerInit();

    player = GET_PLAYER(play);
    if (player == NULL) return;

    Mario_GameplayPreUpdate(play);
    Mario_ReadPlayer(player);
    Mario_ReadInput(play);

    if (sMarioPreUpdateValid) {
        /* Keep MM animation/state processing, but replace vanilla movement. */
        player->actor.world.pos = sMarioPreUpdatePos;
        Mario_PhysicsUpdate(play, player);
    }

    Mario_AnimationUpdate(play, player);
    Mario_GameplayPostUpdate(play);

    gMarioState.frame++;
    gMarioState.actionTimer++;
}
