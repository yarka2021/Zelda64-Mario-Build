#ifndef __MARIO_MOVESET_H__
#define __MARIO_MOVESET_H__

#include "global.h"

typedef enum {
    MARIO_MOVE_NONE = 0,
    MARIO_MOVE_PUNCH,
    MARIO_MOVE_KICK,
    MARIO_MOVE_GROUND_POUND,
} MarioMove;

void Mario_MovesetInit(void);
void Mario_MovesetUpdate(PlayState* play);
bool Mario_MovesetIsAttackActive(void);
MarioMove Mario_MovesetGetCurrent(void);

#endif
