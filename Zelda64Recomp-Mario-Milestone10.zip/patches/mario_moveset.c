#include "mario_moveset.h"
#include "mario_state.h"
#include "mario_proportions.h"
#include "z64.h"

static MarioMove sCurrentMove = MARIO_MOVE_NONE;

void Mario_MovesetInit(void) {
    sCurrentMove = MARIO_MOVE_NONE;
}

MarioMove Mario_MovesetGetCurrent(void) {
    return sCurrentMove;
}

bool Mario_MovesetIsAttackActive(void) {
    return gMarioState.attackActive != 0;
}

void Mario_MovesetUpdate(PlayState* play) {
    (void)play;

    if (gMarioState.attackTimer > 0) {
        gMarioState.attackTimer--;
    } else {
        gMarioState.attackActive = 0;
        sCurrentMove = MARIO_MOVE_NONE;
    }

    /*
     * Mario-native attacks intentionally do not directly damage MM actors here.
     * The hitbox/event bridge is kept separate so existing MM enemy scripting
     * remains authoritative.
     */
    if (gMarioState.pressedButtons & BTN_B) {
        if (gMarioState.grounded && gMarioState.action != MARIO_ACTION_SLIDE) {
            sCurrentMove = MARIO_MOVE_PUNCH;
            gMarioState.action = MARIO_ACTION_ATTACK;
            gMarioState.attackActive = 1;
            gMarioState.attackTimer = 8;
        } else if (!gMarioState.grounded && gMarioState.velocity.y < -2.0f) {
            sCurrentMove = MARIO_MOVE_KICK;
            gMarioState.action = MARIO_ACTION_KICK;
            gMarioState.attackActive = 1;
            gMarioState.attackTimer = 7;
        }
    }

    if ((gMarioState.action == MARIO_ACTION_GROUND_POUND) &&
        gMarioState.grounded) {
        sCurrentMove = MARIO_MOVE_GROUND_POUND;
        gMarioState.attackActive = 1;
        gMarioState.stompActive = 1;
        gMarioState.attackTimer = 5;
    }

    if (gMarioState.stompActive && !gMarioState.grounded) {
        gMarioState.stompActive = 0;
    }
}
