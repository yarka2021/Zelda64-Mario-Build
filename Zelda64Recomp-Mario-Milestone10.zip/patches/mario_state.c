#include "mario_state.h"

MarioState gMarioState;

void Mario_InitState(void) {
    gMarioState.pos.x = 0.0f;
    gMarioState.pos.y = 0.0f;
    gMarioState.pos.z = 0.0f;

    gMarioState.velocity.x = 0.0f;
    gMarioState.velocity.y = 0.0f;
    gMarioState.velocity.z = 0.0f;

    gMarioState.yaw = 0;
    gMarioState.pitch = 0;
    gMarioState.roll = 0;

    gMarioState.forwardVelocity = 0.0f;
    gMarioState.intendedMagnitude = 0.0f;

    gMarioState.stickX = 0.0f;
    gMarioState.stickY = 0.0f;

    gMarioState.heldButtons = 0;
    gMarioState.pressedButtons = 0;

    gMarioState.action = MARIO_ACTION_IDLE;
    gMarioState.actionTimer = 0;
    gMarioState.actionState = 0;

    gMarioState.jumpCount = 0;
    gMarioState.grounded = false;
    gMarioState.wallContact = false;

    gMarioState.wallNormal.x = 0.0f;
    gMarioState.wallNormal.y = 0.0f;
    gMarioState.wallNormal.z = 0.0f;

    gMarioState.floorNormal.x = 0.0f;
    gMarioState.floorNormal.y = 1.0f;
    gMarioState.floorNormal.z = 0.0f;

    gMarioState.gameplayInvulnTimer = 0;
    gMarioState.defeated = false;
    gMarioState.health = 0;
    gMarioState.maxHealth = 0;

    gMarioState.frame = 0;
}
