#include "mario_asset.h"

static MarioAssetPackage sMarioAsset;
static const void* sAnimationMap[32];

void Mario_AssetInit(void) {
    sMarioAsset.name = "none";
    sMarioAsset.skeleton = NULL;
    sMarioAsset.animationTable = NULL;
    sMarioAsset.animationCount = 0;
    sMarioAsset.displayList = NULL;
    sMarioAsset.valid = false;
    sMarioAsset.bind = NULL;

    for (s32 i = 0; i < ARRAY_COUNT(sAnimationMap); i++) {
        sAnimationMap[i] = NULL;
    }
}

bool Mario_AssetInstall(const MarioAssetPackage* package) {
    if (package == NULL || package->skeleton == NULL ||
        package->animationTable == NULL || package->displayList == NULL) {
        return false;
    }

    sMarioAsset = *package;
    sMarioAsset.valid = (package->bind != NULL);
    return true;
}

const MarioAssetPackage* Mario_AssetGet(void) {
    return &sMarioAsset;
}

const void* Mario_AssetAnimation(MarioAnimation animation) {
    if ((s32)animation < 0 || animation >= ARRAY_COUNT(sAnimationMap)) {
        return NULL;
    }
    return sAnimationMap[animation];
}

bool Mario_AssetBind(PlayState* play, Player* player, MarioAnimation animation) {
    if (!sMarioAsset.valid || sMarioAsset.bind == NULL) {
        return false;
    }
    return sMarioAsset.bind(play, player, &sMarioAsset, animation);
}
