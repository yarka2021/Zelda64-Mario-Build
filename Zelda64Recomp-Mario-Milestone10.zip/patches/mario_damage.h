#ifndef __MARIO_DAMAGE_H__
#define __MARIO_DAMAGE_H__

#include "global.h"
#include "mario_state.h"

void Mario_DamageInit(void);
void Mario_DamageUpdate(PlayState* play);
void Mario_ApplyDamage(MarioDamageType type, s16 amount);
void Mario_Respawn(PlayState* play);

#endif
