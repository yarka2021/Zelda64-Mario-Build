#include "mario_damage.h"
#include "mario_state.h"
#include "z64.h"

static void Mario_SetHurtAction(MarioDamageType type) {
    gMarioState.damageType = type;

    if (type == MARIO_DAMAGE_LAVA) {
        gMarioState.action = MARIO_ACTION_LAVA_DAMAGE;
    } else if (type == MARIO_DAMAGE_ELECTRIC) {
        gMarioState.action = MARIO_ACTION_ELECTRIC_DAMAGE;
    } else {
        gMarioState.action = MARIO_ACTION_HURT;
    }
}

void Mario_DamageInit(void) {
    gMarioState.health = 16;
    gMarioState.maxHealth = 16;
    gMarioState.damageType = MARIO_DAMAGE_NONE;
    gMarioState.lifeState = MARIO_LIFE_ALIVE;
    gMarioState.damageTimer = 0;
    gMarioState.invincibilityTimer = 0;
}

void Mario_ApplyDamage(MarioDamageType type, s16 amount) {
    if (gMarioState.lifeState == MARIO_LIFE_DEAD ||
        gMarioState.invincibilityTimer != 0 ||
        amount <= 0) {
        return;
    }

    if (amount > gMarioState.health) {
        amount = gMarioState.health;
    }

    gMarioState.health -= amount;
    gMarioState.damageTimer = 20;
    gMarioState.invincibilityTimer = 45;
    gMarioState.lifeState = (gMarioState.health <= 0) ? MARIO_LIFE_DEAD : MARIO_LIFE_HURT;

    Mario_SetHurtAction(type);

    if (gMarioState.health <= 0) {
        gMarioState.action = MARIO_ACTION_DEATH;
        gMarioState.damageTimer = 60;
    }
}

void Mario_DamageUpdate(PlayState* play) {
    (void)play;

    if (gMarioState.invincibilityTimer > 0) {
        gMarioState.invincibilityTimer--;
    }

    if (gMarioState.damageTimer > 0) {
        gMarioState.damageTimer--;
    }

    if (gMarioState.lifeState == MARIO_LIFE_HURT &&
        gMarioState.damageTimer == 0) {
        gMarioState.lifeState = MARIO_LIFE_ALIVE;
        gMarioState.damageType = MARIO_DAMAGE_NONE;
        if (gMarioState.grounded) {
            gMarioState.action = MARIO_ACTION_IDLE;
        }
    }
}

void Mario_Respawn(PlayState* play) {
    Player* player;

    if (play == NULL) {
        return;
    }

    player = GET_PLAYER(play);
    if (player == NULL) {
        return;
    }

    gMarioState.lifeState = MARIO_LIFE_RESPAWNING;
    gMarioState.health = gMarioState.maxHealth;
    gMarioState.damageType = MARIO_DAMAGE_NONE;
    gMarioState.damageTimer = 0;
    gMarioState.invincibilityTimer = 60;
    gMarioState.velocity.x = 0.0f;
    gMarioState.velocity.y = 0.0f;
    gMarioState.velocity.z = 0.0f;
    gMarioState.action = MARIO_ACTION_IDLE;

    gMarioState.lifeState = MARIO_LIFE_ALIVE;
}
