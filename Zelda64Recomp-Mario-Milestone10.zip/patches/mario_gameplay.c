#include "mario_gameplay.h"
#include "mario_proportions.h"
#include "z64.h"

MarioGameplay gMarioGameplay;

static s16 Mario_ClampHealth(s16 health, s16 maxHealth) {
    if (health < 0) return 0;
    if (maxHealth > 0 && health > maxHealth) return maxHealth;
    return health;
}

void Mario_GameplayInit(void) {
    gMarioGameplay.state = MARIO_GAMEPLAY_ALIVE;
    gMarioGameplay.health = 0;
    gMarioGameplay.maxHealth = 0;
    gMarioGameplay.invulnerabilityTimer = 0;
    gMarioGameplay.interactionActive = false;
    gMarioGameplay.inWater = false;
}

void Mario_GameplaySceneReset(void) {
    Mario_GameplayInit();
    Mario_InitState();
}

void Mario_GameplayPreUpdate(PlayState* play) {
    Player* player;

    if (play == NULL) return;

    player = GET_PLAYER(play);
    if (player == NULL) return;

    /*
     * Keep MM's Player systems authoritative for damage, doors, NPCs,
     * switches, cutscenes, item pickup, and controller lockouts.
     *
     * This bridge only observes their resulting state and exposes it to the
     * Mario animation/gameplay layers. It deliberately does not reimplement
     * those systems.
     */
    gMarioGameplay.health = player->actor.colChkInfo.health;
    gMarioGameplay.maxHealth = player->actor.colChkInfo.health;

    if (gMarioGameplay.health <= 0) {
        gMarioGameplay.state = MARIO_GAMEPLAY_DEFEATED;
        gMarioGameplay.interactionActive = false;
    } else {
        gMarioGameplay.state = MARIO_GAMEPLAY_ALIVE;
    }

    gMarioGameplay.inWater = gMarioState.inWater;
    gMarioState.health = gMarioGameplay.health;
    gMarioState.maxHealth = gMarioGameplay.maxHealth;
    gMarioState.defeated = (gMarioGameplay.state == MARIO_GAMEPLAY_DEFEATED);

    if (gMarioGameplay.invulnerabilityTimer > 0) {
        gMarioGameplay.invulnerabilityTimer--;
    }
    gMarioState.gameplayInvulnTimer = (u8)MIN(gMarioGameplay.invulnerabilityTimer, 255);
}

void Mario_GameplayPostUpdate(PlayState* play) {
    Player* player;

    if (play == NULL) return;

    player = GET_PLAYER(play);
    if (player == NULL) return;

    /*
     * Player interaction is intentionally not duplicated here. If MM has
     * entered an interaction/cutscene/door state, Player remains authoritative.
     * The Mario layer simply prevents its own custom action state from trying
     * to start a movement action while Player is being controlled by MM.
     */
    if (Player_InCsMode(play)) {
        gMarioGameplay.interactionActive = false;
        return;
    }

    gMarioGameplay.interactionActive =
        (player->actor.world.pos.y >= player->actor.floorHeight - 120.0f);

    gMarioState.health = player->actor.colChkInfo.health;
    gMarioState.defeated = (player->actor.colChkInfo.health <= 0);
}

bool Mario_GameplayCanInteract(void) {
    return gMarioGameplay.state == MARIO_GAMEPLAY_ALIVE &&
           gMarioGameplay.invulnerabilityTimer == 0 &&
           gMarioGameplay.interactionActive;
}

bool Mario_GameplayIsAlive(void) {
    return gMarioGameplay.state != MARIO_GAMEPLAY_DEFEATED;
}
