#include "mario_animation.h"

static MarioAnimation sCurrentAnimation = MARIO_ANIM_IDLE;
static u16 sAnimationTimer = 0;

void Mario_AnimationInit(void) {
    sCurrentAnimation = MARIO_ANIM_IDLE;
    sAnimationTimer = 0;
}

MarioAnimation Mario_AnimationForAction(MarioAction action, bool inWater) {
    if (inWater) {
        if (action == MARIO_ACTION_IDLE || action == MARIO_ACTION_FALL) {
            return MARIO_ANIM_WATER_IDLE;
        }
        return MARIO_ANIM_SWIM;
    }

    switch (action) {
        case MARIO_ACTION_WALK: return MARIO_ANIM_WALK;
        case MARIO_ACTION_RUN: return MARIO_ANIM_RUN;
        case MARIO_ACTION_JUMP: return MARIO_ANIM_JUMP;
        case MARIO_ACTION_DOUBLE_JUMP: return MARIO_ANIM_DOUBLE_JUMP;
        case MARIO_ACTION_TRIPLE_JUMP: return MARIO_ANIM_TRIPLE_JUMP;
        case MARIO_ACTION_LONG_JUMP: return MARIO_ANIM_LONG_JUMP;
        case MARIO_ACTION_SIDE_FLIP: return MARIO_ANIM_SIDE_FLIP;
        case MARIO_ACTION_BACKFLIP: return MARIO_ANIM_BACKFLIP;
        case MARIO_ACTION_DIVE: return MARIO_ANIM_DIVE;
        case MARIO_ACTION_GROUND_POUND: return MARIO_ANIM_GROUND_POUND;
        case MARIO_ACTION_WALL_KICK: return MARIO_ANIM_WALL_KICK;
        case MARIO_ACTION_SLIDE: return MARIO_ANIM_SLIDE;
        case MARIO_ACTION_FREEFALL:
        case MARIO_ACTION_FALL: return MARIO_ANIM_FALL;
        default: return MARIO_ANIM_IDLE;
    }
}

MarioAnimation Mario_AnimationCurrent(void) {\n    return sCurrentAnimation;\n}\n\nvoid Mario_AnimationUpdate(PlayState* play, Player* player) {
    MarioAnimation next = Mario_AnimationForAction(gMarioState.action, gMarioState.inWater);

    if (next != sCurrentAnimation) {
        sCurrentAnimation = next;
        sAnimationTimer = 0;
    } else if (sAnimationTimer < 0xFFFF) {
        sAnimationTimer++;
    }

    /*
     * Asset-neutral animation layer.
     *
     * The actual Mario skeleton/animation tables are intentionally not embedded
     * here. When the user supplies a compatible Mario skeleton, this is the one
     * place where MarioAnimation is translated to Animation_* / SkelAnime calls.
     * Keeping that translation separate avoids coupling gameplay physics to the
     * rendering asset.
     */
    (void)play;
    (void)player;
}

const char* Mario_AnimationName(MarioAnimation animation) {
    switch (animation) {
        case MARIO_ANIM_IDLE: return "idle";
        case MARIO_ANIM_WALK: return "walk";
        case MARIO_ANIM_RUN: return "run";
        case MARIO_ANIM_JUMP: return "jump";
        case MARIO_ANIM_FALL: return "fall";
        case MARIO_ANIM_DOUBLE_JUMP: return "double_jump";
        case MARIO_ANIM_TRIPLE_JUMP: return "triple_jump";
        case MARIO_ANIM_LONG_JUMP: return "long_jump";
        case MARIO_ANIM_SIDE_FLIP: return "side_flip";
        case MARIO_ANIM_BACKFLIP: return "backflip";
        case MARIO_ANIM_DIVE: return "dive";
        case MARIO_ANIM_GROUND_POUND: return "ground_pound";
        case MARIO_ANIM_WALL_KICK: return "wall_kick";
        case MARIO_ANIM_SLIDE: return "slide";
        case MARIO_ANIM_SWIM: return "swim";
        case MARIO_ANIM_WATER_IDLE: return "water_idle";
        case MARIO_ANIM_LAND: return "land";
        default: return "unknown";
    }
}
