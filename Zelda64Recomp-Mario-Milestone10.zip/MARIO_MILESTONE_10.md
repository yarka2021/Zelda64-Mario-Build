# Mario Milestone 10 — Mario Moveset + MM Gameplay Compatibility

This milestone adds a Mario-native moveset layer while keeping Majora's Mask
systems authoritative for scripted gameplay.

## Added

- `mario_moveset.h/.c`
  - punch
  - kick
  - ground-pound attack state
  - attack-active timer
- `mario_damage.h/.c`
  - health
  - invulnerability window
  - generic/fire/lava/ice/electric/fall damage types
  - hurt/death states
  - respawn reset
- `MarioState` now stores health/life/damage/attack state.

## Compatibility rule

This milestone does NOT blindly replace MM's enemy, NPC, door, item, or
cutscene systems. The Mario layer produces an attack/damage state; a later
hitbox bridge can translate that state into the existing MM collision/actor
systems.

This avoids making every existing MM enemy understand a new custom attack
format at once.

## Controls

- B on ground: Mario punch
- B in falling state: Mario kick
- Ground pound landing: stomp/attack state

The exact animation and hitbox are intentionally separated from the action
state, so they can be tuned in Milestone 11.

## Important

The source milestone is not a compiled ROM/ELF. The uploaded project does not
contain all git submodule contents needed for a complete build.
