# Mario Controller — Milestone 3

This archive extends Milestone 2 with an SM64-inspired action state machine.

## Added actions

- Idle / Walk / Run
- Jump
- Double Jump
- Triple Jump
- Long Jump
- Side Flip
- Backflip
- Dive
- Ground Pound
- Freefall / Fall

## Default controls

- **Stick** — move
- **B** — run
- **A** — jump / chained jump
- **Z + A** while moving — long jump
- **Z + A** in the air — ground pound
- **B** in the air — dive
- **A + stick sideways** at low speed — side flip
- **A + stick backward** at low speed — backflip

The exact controls can be remapped later; the important part is that the action layer is now separated from the physics layer.

## Collision

MM's `BgCheck_EntityRaycastFloor5_3` remains the authoritative floor query. Wall collision and slope-normal movement are intentionally not faked yet; they are the next collision milestone.

## Build note

The patch Makefile already compiles `*.c` via a wildcard, so the new source does not require a CMake source-list change.

The uploaded source archive does not contain the full `lib/mm-decomp` / symbol submodule contents, so this milestone was not claimed as a locally compiled ELF. Build it in the normal Zelda64Recomp development checkout after initializing its submodules.
