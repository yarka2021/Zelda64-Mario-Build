# Mario Milestone 6 — Model & Animation Layer

## What this milestone adds

- `mario_animation.h/.c`: action-to-animation state machine.
- `mario_model.h/.c`: asset boundary for a user-supplied Mario skeleton/display-list package.
- Mario animation state is updated every gameplay frame.
- Animation IDs cover idle, walk, run, jump variants, fall, long jump, side/back flip, dive, ground pound, wall kick, slide and water movement.
- Gameplay physics remains independent from rendering assets.

## Why the actual model is not included

Zelda 64: Recompiled does not distribute original game assets, and this milestone therefore does not embed Nintendo's Mario 64 model or animations. The MM decompilation treats skeletons and animations as extracted assets; a compatible Mario asset package can be added at this boundary.

## Integration point

When a legally obtained/created Mario asset package is available:

1. Implement `Mario_ModelInit()` to register/prepare the skeleton and animation tables.
2. Set `sMarioModelReady` when the asset is ready.
3. Implement `Mario_ModelDraw()` using the project's `SkelAnime`/`Player_DrawImpl` rendering conventions.
4. Translate `MarioAnimation` values from `Mario_AnimationForAction()` into the asset's animation table.
5. Replace the human Player draw call only when `Mario_ModelIsReady()` is true.

## Current visual behavior

This milestone is intentionally asset-neutral. It does **not** fake a Mario mesh or copy Link's mesh and call it Mario. The controller and animation state are ready for the real model package.
