# Mario Milestone 8 — Camera & Proportions

This milestone tunes Mario's visual proportions and camera framing without
replacing Majora's Mask's complete camera system.

## Added

- `patches/mario_proportions.h/.c`
  - one central profile for model scale, camera target/eye height, wall radius
    and wall height.
- `patches/mario_camera.h/.c`
  - vertical camera framing correction after the normal MM camera update.
- Player model scaling is applied only when a custom Mario asset package is
  actually installed.
- Mario collision wall/ceiling dimensions now come from the same profile.

## Camera design

MM remains responsible for:
- camera yaw
- camera collision
- Z-targeting
- scene/cutscene camera modes
- horizontal tracking

The Mario layer only adjusts vertical framing so the shorter/different-sized
Mario model does not look incorrectly framed.

## Tuning

Edit `sMarioProportions` in `patches/mario_proportions.c`:

- `modelScale` — visual Mario scale relative to the original Player scale.
- `cameraTargetHeight` — point on Mario the camera aims toward.
- `cameraEyeHeight` — desired camera eye height.
- `cameraEyeFollow` — how much of the eye-height correction is applied.
- `wallRadius` / `wallHeight` — collision dimensions used by Mario physics.

No Nintendo model, texture, animation, or other copyrighted game asset is
included in this milestone.

## Important

This is a source milestone and has not been compiled here because the
uploaded Zelda64Recomp archive does not contain all git submodule contents.
