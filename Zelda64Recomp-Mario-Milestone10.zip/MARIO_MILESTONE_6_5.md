# Mario Milestone 6.5 — Model/Animation Asset Pipeline

This milestone turns the Milestone 6 visual layer into a replaceable asset
pipeline.

## Added

- `patches/mario_asset.h/.c`
- Mario asset package registration
- explicit animation-slot contract
- model install API
- asset directory/documentation at `assets/mario/`
- controller initialization for the animation/model layers

## Important

No Nintendo Mario 64 model, textures, skeleton, or animation data are
included. The repository only defines the runtime boundary.

A legal/custom model can be converted into the runtime structures expected by
`MarioAssetPackage`, then installed from a mod-specific asset integration
unit.

## Runtime flow

Input -> MarioAction -> MarioAnimation -> MarioAssetAnimation -> Mario model

The physics/controller code remains independent from the model source format.

## Next

The remaining work is the concrete importer/draw adapter for the chosen
Mario model package. That adapter should bind the package skeleton to the
MM `SkelAnime`/animation context and replace the vanilla Player visual draw
path while retaining Player for collision/gameplay.
