# Mario 64 x Majora's Mask — Milestone 1

This patch adds the first Mario controller layer without changing Majora's Mask movement.

## Included

- `patches/mario_state.h/.c`: SM64-inspired `MarioState` storage.
- `patches/mario_controller.h/.c`: reads the MM Player actor and controller input each frame.
- `patches/play_patches.c`: calls `Mario_PlayerHook()` after the original `Play_Update()`.

## Current behavior

The original Link/Player controller remains in charge of movement. `MarioState` mirrors:

- position
- velocity
- rotation
- analog stick
- held/pressed buttons
- grounded state
- a minimal action state: IDLE/WALK/JUMP/FALL

No Mario physics is applied yet.

## Build

The existing `patches/Makefile` uses `$(wildcard *.c)`, so the new C files are automatically included in `patches.elf`; no CMake source-list change is required.

Build using the normal Zelda64Recomp development build process from `BUILDING.md`.

The archive does not contain the MM decomp submodule contents, because the uploaded source archive did not include them. The normal recursive clone/submodule setup is therefore still required before compiling.
