# Mario Controller — Milestone 2

This archive extends Milestone 1 with a first working Mario-style movement layer.

## Added

- `patches/mario_physics.h`
- `patches/mario_physics.c`
- `Mario_PrePlayUpdate()` hook
- acceleration / deceleration
- walk speed and B-button run speed
- camera-relative direction is **not** implemented yet; movement is relative to current Player yaw
- gravity and terminal fall speed
- A-button ground jump
- MM floor raycast for landing
- Player X/Z/Y position and velocity are driven by the Mario controller after the vanilla Player update

## Important

This is an intermediate physics layer, not the final SM64 controller.

Wall collision, slope projection, sliding, double/triple jump, long jump, side/back flip,
dive, ground pound, wall kick, and the final camera-relative input mapping are intentionally
left for later milestones.

The project archive supplied for this work does not contain the `lib/mm-decomp` submodule,
so this milestone was not compiled in this environment. After restoring the project's
submodules, run the normal patch build to catch any version-specific prototype differences.

## Build

The existing `patches/Makefile` uses `$(wildcard *.c)`, so the new C files are automatically
included; no manual source-list edit is required.
